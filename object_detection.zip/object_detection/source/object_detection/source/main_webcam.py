'''Import relevant modules
import cv2
import numpy as np
import os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import urllib.request
from datetime import datetime


#url='http://192.168.189.32/cam-hi.jpg'

# Fetch the service account key JSON file contents
cred = credentials.Certificate('obst-fe4b6-firebase-adminsdk-855kg-086420fbe3.json')

# Initialize the app with a service account, granting admin privileges

firebase_admin.initialize_app(cred, {
    'databaseURL': "https://obst-fe4b6-default-rtdb.firebaseio.com/"
})

#Read in the image file
thres = 0.45 #Threshold to detect object
nms_threshold = 0.5 #NMS
cap = cv2.VideoCapture(0)

cap.set(3,1280)
cap.set(4,720)
cap.set(10,150)


#Import the class names
classNames = []
classFile = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'coco.names'))


# Read object classes
with open(classFile, 'rt') as f:
    classNames = f.read().rstrip('\n').split('\n')

#Import the config and weights file
os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'coco.names'))
configPath =  os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'))
weightsPath = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'frozen_inference_graph.pb')) #Weights derived from training on large objects dataset

#Set relevant parameters
net = cv2.dnn_DetectionModel(weightsPath,configPath)

#These are some suggested settings from the tutorial, others are fine but this can be used as a baseline
net.setInputSize(320,320)
net.setInputScale(1.0/127.5)
net.setInputMean((127.5,127.5,127.5))
net.setInputSwapRB(True)

while True:
    # Start Webcam
    #success, image = cap.read()

    img_resp=urllib.request.urlopen(cap)
    imgnp=np.array(bytearray(img_resp.read()),dtype=np.uint8)
    image=cv2.imdecode(imgnp,-1)

    # Tuple unpacking net.detect provides ID of object, confidence and bounding box
    classIds, confs, bbox = net.detect(image,confThreshold = thres)
    
    # It's not in a nice format to print, so it needs to be cleaned up
    bbox = list(bbox) #NMS function required bbox as a list, not a tuple
    confs = list(np.array(confs).reshape(1,-1)[0]) #[0] removed extra bracket, and reshape used to get the values on the same row
    confs = list(map(float,confs))
    #print(classIds, confs,bbox)

    # Extract co-ordinates of bounding box (with NMS)
    indicies = cv2.dnn.NMSBoxes(bbox,confs,thres,nms_threshold)
    
    # add boxes for each detection on each frame
    print(indicies)
    for i in indicies:
        i = indicies[0] #Get the bounding box info
        box = bbox[i]
        x,y,w,h = box[0],box[1],box[2],box[3]
        cv2.rectangle(image,(x,y),(x+w,h+y),color = (0,255,0), thickness =2)
        print(classNames[classIds[i]-1])
        res = classNames[classIds[i]-1]
        cv2.putText(image,classNames[classIds[i]-1],(box[0]+10,box[1]+30),cv2.FONT_HERSHEY_COMPLEX,1,(0,255,0),2)
        ref = db.reference('CHILD_IOT')
        ref.set({'OBJ_STATUS': res})
        val = ref.get()
        val = dict(val)
        print(val.get('Dist'))

    # Show output until CTRL+C 
    cv2.imshow("Output", image)
    cv2.waitKey(1)
 
    #Without NMS
    #if len(classIds) != 0:
        #for classId, confidence, box in zip(classIds.flatten(),confs.flatten(),bbox):
            #cv2.rectangle(image,box,color=(0,255,0), thickness=2)
            #cv2.putText(image,classNames[classId-1],(box[0]+10,box[1]+30),
                        #cv2.FONT_HERSHEY_COMPLEX,1,(0,255,0),2)


    
'''
import cv2
import numpy as np
import os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

# Firebase initialization
cred = credentials.Certificate('iotrobo-d1b13-firebase-adminsdk-r1oxf-3204844089.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://iotrobo-d1b13-default-rtdb.firebaseio.com/"
})

# Load class names
classNames = []
classFile = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'coco.names'))
with open(classFile, 'rt') as f:
    classNames = f.read().rstrip('\n').split('\n')

# Classes to detect (from COCO dataset)
detect_classes = ['person', 'bicycle', 'car', 'motorbike', 'bus', 'truck', 'cat', 'dog', 'hole', 'pit']

# Load object detection model
configPath = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'))
weightsPath = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'frozen_inference_graph.pb'))
net = cv2.dnn_DetectionModel(weightsPath, configPath)
net.setInputSize(320, 320)
net.setInputScale(1.0 / 127.5)
net.setInputMean((127.5, 127.5, 127.5))
net.setInputSwapRB(True)

# Webcam capture
cap = cv2.VideoCapture(0)
cap.set(3, 1280)  # Set width
cap.set(4, 720)   # Set height
cap.set(10, 150)  # Set brightness

# Main loop
while True:
    # Read frame from webcam
    success, image = cap.read()
    if not success:
        print("Failed to capture image from camera.")
        break
    
    # Object detection
    classIds, confs, bbox = net.detect(image, confThreshold=0.45)
    
    # Flag to determine if any relevant class is detected
    stop_detected = False
    
    if len(classIds) > 0:
        for classId, confidence, box in zip(classIds.flatten(), confs.flatten(), bbox):
            className = classNames[classId-1]
            
            # Check if detected class is in our desired classes
            if className.lower() in detect_classes:
                stop_detected = True
                x, y, w, h = box
                cv2.rectangle(image, (x, y), (x+w, y+h), color=(0, 255, 0), thickness=2)
                cv2.putText(image, className, (x+10, y+30), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
                
                # Update Firebase with detected object (optional)
                ref = db.reference('CHILD_IOT')
                ref.set({'OBJ_STATUS': 'STOP'})
            else:
                # Update Firebase with "FORWARD" if no relevant class is detected
                ref = db.reference('CHILD_IOT')
                ref.set({'OBJ_STATUS': 'FORWARD'})
    
    # Display the frame with detection results
    cv2.imshow("Object Detection", image)
    
    # Exit on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release resources
cap.release()
cv2.destroyAllWindows()

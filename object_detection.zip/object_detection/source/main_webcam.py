import cv2
import numpy as np
import os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
import urllib.request
from datetime import datetime

import cv2
import numpy as np
import os
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db

# Firebase initialization
cred = credentials.Certificate('iotbasedsmartagriculture-2ca20-firebase-adminsdk-b84vn-b55023f1db.json')
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://iotbasedsmartagriculture-2ca20-default-rtdb.firebaseio.com/"
})

# Load class names
classNames = []
classFile = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'coco.names'))
with open(classFile, 'rt') as f:
    classNames = f.read().rstrip('\n').split('\n')

# Classes to detect (from COCO dataset)
detect_classes = ['person', 'bicycle', 'car', 'motorbike', 'bus', 'truck', 'cat', 'dog', 'hole', 'pit']

# Load object detection model
configPath = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'ssd_mobilenet_v3_large_coco_2020_01_14.pbtxt'))
weightsPath = os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config_files', 'frozen_inference_graph.pb'))
net = cv2.dnn_DetectionModel(weightsPath, configPath)
net.setInputSize(320, 320)
net.setInputScale(1.0 / 127.5)
net.setInputMean((127.5, 127.5, 127.5))
net.setInputSwapRB(True)

# Webcam capture
cap = cv2.VideoCapture(0)
cap.set(3, 1280)  # Set width
cap.set(4, 720)   # Set height
cap.set(10, 150)  # Set brightness

# Main loop
while True:
    # Read frame from webcam
    success, image = cap.read()
    if not success:
        print("Failed to capture image from camera.")
        break
    
    # Object detection
    classIds, confs, bbox = net.detect(image, confThreshold=0.45)
    
    # Flag to determine if any relevant class is detected
    stop_detected = False
    
    if len(classIds) > 0:
        for classId, confidence, box in zip(classIds.flatten(), confs.flatten(), bbox):
            className = classNames[classId-1]
            
            # Check if detected class is in our desired classes
            if className.lower() in detect_classes:
                stop_detected = True
                x, y, w, h = box
                cv2.rectangle(image, (x, y), (x+w, y+h), color=(0, 255, 0), thickness=2)
                cv2.putText(image, className, (x+10, y+30), cv2.FONT_HERSHEY_COMPLEX, 1, (0, 255, 0), 2)
                
                # Update Firebase with detected object (optional)
                ref = db.reference('VMR_AGG')
                ref.set({'device': '1'})
            else:
                # Update Firebase with "FORWARD" if no relevant class is detected
                ref = db.reference('VMR_AGG')
                ref.set({'device': '0'})
    
    # Display the frame with detection results
    cv2.imshow("Object Detection", image)
    
    # Exit on 'q' key press
    if cv2.waitKey(1) & 0xFF == ord('q'):
        ref = db.reference('VMR_AGG')
        ref.set({'device': '0'})
        break

# Release resources
cap.release()
cv2.destroyAllWindows()
